* Change how some items act on enemies (Tesla, Nkuhanas Opinion, Little Disciple, Helfire Tincture)



## Enemy Item behavior changes
I wanted to keep item variety up with for Evo/Vengence/Scav/etc. but some items are just far too overpowered without changes.\
These changes only apply to enemies, the players items should be entirely unchanged.

Nkuhanas Opinion will now deal damage mostly based on base hp.\
Amount of BoostHealth is added to that damage. (T1 elite has 30, T2 has 170).

Tesla Coil is unchanged for Hurt Mithrix/Scavs/Umbras as their stats are meant to (kinda) not be unfair with items.\
Tesla Coil will only account for base damage up to 20, enemies with more than 20 base damage will be treated as 20 base damage.\
Tesla Coil will gain less of a bonus from elite damage boosts.\
Tesla Coil will deal 1/10th the damage.\
Tesla Coil will have a proc coeff of 0.6 instead of 03.

Little Disciple has a proc coeff of 0. (Like Razorwire from Umbras).

Helfire Tincture deals 1/72th the damage.\
Helfire Tincutre is Non Lethal.\
If you get caught your Health should rapidly dip to almost 0 but paired with Umbras often dying to Helfire themselves this should be sorta balanced.


(not in the mod at the moment)